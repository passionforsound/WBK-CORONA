Auf jeden abändern (kurz Aufgabe am besten angucken), sonst hart obvious.
Bei den 10 Vokabeln hab ich z.B. 30...da kannste dir easy 10 raussuchen.